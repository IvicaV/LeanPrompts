/**
 * ============================================================================
 * LeanPrompts Studio
 * @author       Ivica Vrgoc
 * @link         https://github.com/IvicaV/LeanPrompts
 * @copyright    Copyright (c) 2025-present Ivica Vrgoc. All rights reserved.
 * @license      AGPL-3.0
 * ============================================================================
 * This file is part of LeanPrompts Studio.
 * 
 * LeanPrompts Studio is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Affero General Public License for more details.
 * ============================================================================
 */const l=(u,e)=>{const r=[],t=[u];for(;t.length>0;){const n=t.pop();if(n&&(n.nodeType===Node.ELEMENT_NODE&&e(n)&&r.push(n),n.shadowRoot&&t.push(n.shadowRoot),n.children&&n.children.length>0))for(let a=n.children.length-1;a>=0;a--)t.push(n.children[a])}return r},f=(u,e=5e3)=>new Promise(r=>{const t=Date.now(),n=()=>{if(typeof window<"u"&&window.__LP_CONTEXT_INVALIDATED)return r(null),!0;try{const a=u();if(a instanceof HTMLElement||a&&a.nodeType===Node.ELEMENT_NODE)return r(a),!0}catch{}return Date.now()-t>e?(r(null),!0):(setTimeout(()=>requestAnimationFrame(n),100),!1)};n()});let b=0,g=null;const m=()=>{const u=Date.now();if(u-b<400)return g&&g.isConnected?g:null;b=u;const t=l(document,n=>{const a=n.tagName.toLowerCase();return!!(a==="textarea"||a==="input"&&(n.type==="text"||n.type==="search"||n.type==="email")||n.isContentEditable||n.getAttribute("role")==="textbox"||n.getAttribute("contenteditable")==="true")}).filter(n=>{const a=window.getComputedStyle(n);if(a.display==="none"||a.visibility==="hidden"||a.opacity==="0"||n.disabled||n.getAttribute("aria-disabled")==="true"||n.readOnly)return!1;const o=n.getBoundingClientRect();return o.width>20&&o.height>20});return t.length===0?(g=null,null):(t.sort((n,a)=>{const o=n.getBoundingClientRect(),i=a.getBoundingClientRect(),s=window.innerHeight;let c=0,p=0;const h=o.width*o.height,w=i.width*i.height;c+=Math.min(h,1e5)/100,p+=Math.min(w,1e5)/100;const T=n.tagName==="TEXTAREA"||n.isContentEditable,S=a.tagName==="TEXTAREA"||a.isContentEditable;return T&&(c+=500),S&&(p+=500),o.top>s*.5&&(c+=50),i.top>s*.5&&(p+=50),p-c}),g=t[0],g)};/**
 * ============================================================================
 * LeanPrompts Studio
 * @author       Ivica Vrgoc
 * @link         https://github.com/IvicaV/LeanPrompts
 * @copyright    Copyright (c) 2025-present Ivica Vrgoc. All rights reserved.
 * @license      AGPL-3.0
 * ============================================================================
 * This file is part of LeanPrompts Studio.
 * 
 * LeanPrompts Studio is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Affero General Public License for more details.
 * ============================================================================
 */class d{constructor(e,r){this.name=e,this.domains=r}detect(e){return this.domains.some(r=>e.includes(r))}async isReady(){return!!await this.getInput()}getInput(){return m()}getFileInput(){return document.querySelector('input[type="file"]')}async triggerHumanSimulation(e){if(!e)return;const r=["keydown","keypress","input","keyup","change"];for(const t of r)e.dispatchEvent(new Event(t,{bubbles:!0,cancelable:!0,composed:!0})),t==="input"&&await new Promise(n=>setTimeout(n,20))}async injectText(e,r){if(!e||!r)return!1;e.focus(),await new Promise(n=>setTimeout(n,100)),document.body.contains(e)||(e=this.getInput()||e);let t=!1;try{t=document.execCommand("insertText",!1,r)}catch{}if(!t)try{const n=new DataTransfer;n.setData("text/plain",r);const a=new ClipboardEvent("paste",{clipboardData:n,bubbles:!0,cancelable:!0,composed:!0});e.dispatchEvent(a),t=!0}catch{}if(!t&&(e.tagName==="TEXTAREA"||e.tagName==="INPUT"))try{const n=e.tagName==="TEXTAREA"?window.HTMLTextAreaElement.prototype:window.HTMLInputElement.prototype;Object.getOwnPropertyDescriptor(n,"value").set.call(e,r),t=!0}catch{e.value=r,t=!0}if(!t&&e.isContentEditable)try{e.innerText=r,t=!0}catch{}return t?(await this.triggerHumanSimulation(e),this.verifyInjection(e,r),!0):!1}async verifyInjection(e,r){if(!e)return!1;await new Promise(n=>setTimeout(n,150)),document.body.contains(e)||(e=this.getInput()||e);const t=n=>(n||"").replace(/[\u200B-\u200D\uFEFF]/g,"").replace(/[*#_~`>+\-]/g,"").replace(/\u00A0/g," ").replace(/\s+/g," ").trim().toLowerCase();for(let n=0;n<5;n++){const a=t(e.value||e.innerText||""),o=t(r).substring(0,10);if(o.length<3||a.includes(o))return!0;n<4&&(await this.triggerHumanSimulation(e),await new Promise(i=>setTimeout(i,200)))}return console.warn(`LeanPrompts: Verification failed. Expected part of: "${r.substring(0,20)}..." but found: "${(e.value||e.innerText||"").substring(0,30)}..."`),!1}async injectFiles(e){if(!e||e.length===0)return!1;const r=await this.getFileInput();if(!r)return!1;const t=await this._prepareDataTransfer(e);try{const n=window.HTMLInputElement.prototype;Object.getOwnPropertyDescriptor(n,"files").set.call(r,t.files)}catch{r.files=t.files}return r.dispatchEvent(new Event("change",{bubbles:!0,composed:!0})),r.dispatchEvent(new Event("input",{bubbles:!0,composed:!0})),!0}async _prepareDataTransfer(e){const r=await Promise.all(e.map(n=>fetch(n.data).then(a=>a.blob()).then(a=>{const o=n.name||"",i=/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(o.split(".")[0]),s=o&&!i?o:`attachment_${Date.now().toString().slice(-4)}.${(n.type||"bin").split("/")[1]||"dat"}`;return new File([a],s,{type:n.type,lastModified:Date.now()})}))),t=new DataTransfer;return r.forEach(n=>{try{t.items.add(n)}catch{}}),t}dispatchDropSequence(e,r){if(!e)return!1;try{const t=n=>new DragEvent(n,{bubbles:!0,cancelable:!0,composed:!0,dataTransfer:r,clientX:e.getBoundingClientRect().left+10,clientY:e.getBoundingClientRect().top+10});return e.dispatchEvent(t("dragenter")),e.dispatchEvent(t("dragover")),e.dispatchEvent(t("drop")),!0}catch{return!1}}}/**
 * ============================================================================
 * LeanPrompts Studio
 * @author       Ivica Vrgoc
 * @link         https://github.com/IvicaV/LeanPrompts
 * @copyright    Copyright (c) 2025-present Ivica Vrgoc. All rights reserved.
 * @license      AGPL-3.0
 * ============================================================================
 * This file is part of LeanPrompts Studio.
 * 
 * LeanPrompts Studio is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Affero General Public License for more details.
 * ============================================================================
 */class v extends d{constructor(){super("ChatGPT",["chatgpt.com","chat.openai.com"])}getInput(){return document.querySelector("#prompt-textarea")}getFileInput(){return document.querySelector('input[type="file"]:not([id*="upload-photo"])')||document.querySelector('input[type="file"]')}async injectText(e,r){if(!e||!r)return!1;e.focus();try{e.click()}catch{}if(await new Promise(t=>setTimeout(t,150)),e.isContentEditable||e.tagName==="DIV"||e.id==="prompt-textarea")try{const t=window.getSelection(),n=document.createRange();n.selectNodeContents(e),n.collapse(!1),t.removeAllRanges(),t.addRange(n)}catch{}if(e.isContentEditable||e.id==="prompt-textarea"){e.focus();try{const t=new DataTransfer;t.setData("text/plain",r),e.dispatchEvent(new ClipboardEvent("paste",{bubbles:!0,cancelable:!0,composed:!0,clipboardData:t})),e.dispatchEvent(new InputEvent("input",{bubbles:!0,cancelable:!0,composed:!0,inputType:"insertFromPaste"}))}catch{try{document.execCommand("insertText",!1,r)}catch{}await this.triggerHumanSimulation(e)}return!0}return await super.injectText(e,r)}async verifyInjection(e,r){return!0}async injectFiles(e){if(!e||e.length===0)return!1;const r=this.getInput();if(!r)return!1;try{r.focus(),r.click(),await new Promise(c=>setTimeout(c,100));const t=document.querySelector('button[aria-label*="Attach"]')||document.querySelector('button[aria-label*="Anhängen"]')||document.querySelector('button[aria-label*="attach"]')||document.querySelector('button[data-testid="attach-button"]')||Array.from(document.querySelectorAll("button")).find(c=>c.innerHTML.includes("path")&&(c.innerHTML.includes("M12 5v14")||c.innerHTML.includes("clip")||c.innerHTML.includes("attach")));t&&(t.click(),await f(()=>{const c=this.getFileInput();return c&&c.isConnected?c:null},3e3));let n=this.getFileInput();if(n||(n=await f(()=>this.getFileInput(),2e3)),!n)return console.error("LeanPrompts: ChatGPT file input not found after priming"),!1;const a=await this._prepareDataTransfer(e),o=window.HTMLInputElement.prototype;return Object.getOwnPropertyDescriptor(o,"files").set.call(n,a.files),n.dispatchEvent(new Event("change",{bubbles:!0,composed:!0})),n.dispatchEvent(new Event("input",{bubbles:!0,composed:!0})),await new Promise(c=>setTimeout(c,500)),(document.querySelector('button[aria-label="Close"]')||document.body).click(),r.focus(),!0}catch(t){return console.error("ChatGPT file injection failed",t),!1}}}/**
 * ============================================================================
 * LeanPrompts Studio
 * @author       Ivica Vrgoc
 * @link         https://github.com/IvicaV/LeanPrompts
 * @copyright    Copyright (c) 2025-present Ivica Vrgoc. All rights reserved.
 * @license      AGPL-3.0
 * ============================================================================
 * This file is part of LeanPrompts Studio.
 * 
 * LeanPrompts Studio is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Affero General Public License for more details.
 * ============================================================================
 */class E extends d{constructor(){super("Claude",["claude.ai"])}getInput(){return document.querySelector('[contenteditable="true"]')||m()}async getFileInput(){return await f(()=>document.querySelector('input[type="file"]')||l(document,e=>e.tagName==="INPUT"&&e.type==="file")[0],3e3)}async injectText(e,r){if(!e||!r)return!1;e.focus();try{e.click()}catch{}if(await new Promise(t=>setTimeout(t,150)),e.isContentEditable||e.tagName==="DIV")try{const t=window.getSelection(),n=document.createRange();n.selectNodeContents(e),n.collapse(!1),t.removeAllRanges(),t.addRange(n)}catch{}return await super.injectText(e,r)}}/**
 * ============================================================================
 * LeanPrompts Studio
 * @author       Ivica Vrgoc
 * @link         https://github.com/IvicaV/LeanPrompts
 * @copyright    Copyright (c) 2025-present Ivica Vrgoc. All rights reserved.
 * @license      AGPL-3.0
 * ============================================================================
 * This file is part of LeanPrompts Studio.
 * 
 * LeanPrompts Studio is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Affero General Public License for more details.
 * ============================================================================
 */class x extends d{constructor(){super("Gemini",["gemini.google.com"])}getInput(){const e=document.querySelector("rich-textarea");if(e&&e.shadowRoot){const t=e.shadowRoot.querySelector('div[contenteditable="true"]')||e.shadowRoot.querySelector(".ql-editor")||e.shadowRoot.querySelector('p[contenteditable="true"]');if(t)return t}const r=['rich-textarea div[contenteditable="true"]',"div.ql-editor",'div[contenteditable="true"][role="textbox"]',"rich-textarea p"];for(const t of r){const n=document.querySelector(t);if(n)return n}return m()}async verifyInjection(e,r){if(!e)return!1;document.body.contains(e)||(e=this.getInput()||e);const t=a=>(a||"").replace(/[\u200B-\u200D\uFEFF]/g,"").replace(/[*#_~`>+\-]/g,"").replace(/\u00A0/g," ").replace(/\s+/g," ").trim().toLowerCase(),n=t(r).substring(0,15);for(let a=0;a<10;a++){const o=e.value!==void 0?e.value:"";if(t(o+" "+e.innerText+" "+e.textContent).includes(n))return!0;a%2===0&&await this.triggerHumanSimulation(e),await new Promise(s=>setTimeout(s,400))}return!1}async getFileInput(){const e=()=>document.querySelector('input[name="Filedata"]')||document.querySelector('input[type="file"]');if(e())return e();const r=await f(()=>document.querySelector('button[aria-label*="Datei hochladen"]')||document.querySelector('button[aria-label*="Upload"]')||document.querySelector('button[aria-label*="hochladen"]'),5e3);if(r){if(r.click(),await new Promise(n=>setTimeout(n,800)),e())return e();const t=await f(()=>document.querySelector('button[aria-label*="Dateien hochladen"]')||document.querySelector('button[aria-label*="Upload files"]')||Array.from(document.querySelectorAll("button")).find(n=>{var a,o;return((a=n.innerText)==null?void 0:a.includes("Dateien hochladen"))||((o=n.innerText)==null?void 0:o.includes("Upload files"))}),3e3);t&&(t.click(),await new Promise(n=>setTimeout(n,800)))}return await f(()=>e(),3e3)}}/**
 * ============================================================================
 * LeanPrompts Studio
 * @author       Ivica Vrgoc
 * @link         https://github.com/IvicaV/LeanPrompts
 * @copyright    Copyright (c) 2025-present Ivica Vrgoc. All rights reserved.
 * @license      AGPL-3.0
 * ============================================================================
 * This file is part of LeanPrompts Studio.
 * 
 * LeanPrompts Studio is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Affero General Public License for more details.
 * ============================================================================
 */class I extends d{constructor(){super("Google AI Studio",["aistudio.google.com"]),this._lastDeepScanTime=0,this._cachedDeepScanResult=null}getInput(){let e=document.querySelector("ms-prompt-box textarea, ms-text-box textarea, .prompt-box-container textarea")||document.querySelector('textarea[formcontrolname*="prompt"], textarea[aria-label*="prompt"], textarea[placeholder*="prompt"]')||document.querySelector('textarea[placeholder*="Type"], textarea[aria-label*="Type"], textarea[placeholder*="Ask"], textarea[aria-label*="Ask"], textarea[placeholder*="Enter"], textarea[aria-label*="Enter"]');if(e&&(e.offsetWidth>0||e.offsetHeight>0))return e;const r=Date.now();if(r-this._lastDeepScanTime<400)return this._cachedDeepScanResult&&this._cachedDeepScanResult.isConnected?this._cachedDeepScanResult:null;this._lastDeepScanTime=r;const n=l(document,a=>a.tagName==="TEXTAREA").filter(a=>{if(a.disabled||a.readOnly||a.getAttribute("aria-disabled")==="true")return!1;const o=window.getComputedStyle(a);return!(o.display==="none"||o.visibility==="hidden"||a.offsetWidth===0||a.offsetHeight===0)});if(n.length>0){const a=n.find(o=>{const i=(o.getAttribute("formcontrolname")||o.getAttribute("aria-label")||o.placeholder||"").toLowerCase();if(i.includes("prompt")||i.includes("type")||i.includes("ask")||i.includes("enter")||i.includes("user"))return!0;let s=o.parentElement,c=0;for(;s&&c<3;){const p=s.className||"";if(typeof p=="string"&&(p.includes("prompt")||p.includes("chat")||p.includes("input")))return!0;s=s.parentElement,c++}return!1});return this._cachedDeepScanResult=a||n[0],this._cachedDeepScanResult}return this._cachedDeepScanResult=null,null}async getFileInput(){const e=document.querySelector("input[data-test-upload-file-input]")||document.querySelector('input[type="file"].file-input')||document.querySelector('input[type="file"]')||l(document,t=>t.tagName==="INPUT"&&t.type==="file")[0];if(e)return e;const r=document.querySelector('button[aria-label*="Insert"], button[aria-label*="images"], button[aria-label*="Hinzufügen"]');return r&&(r.click(),await new Promise(t=>setTimeout(t,600))),document.querySelector("input[data-test-upload-file-input]")||document.querySelector('input[type="file"].file-input')||document.querySelector('input[type="file"]')||l(document,t=>t.tagName==="INPUT"&&t.type==="file")[0]||await f(()=>document.querySelector('input[type="file"]'),3e3)}async injectText(e,r){if(!r)return!1;for(let t=0;t<15;t++){if((!e||!e.isConnected||e.offsetWidth===0&&e.offsetHeight===0)&&(e=this.getInput()),e&&!e.disabled&&!e.readOnly){try{e.focus(),e.click()}catch{}break}await new Promise(n=>setTimeout(n,200))}return e?await super.injectText(e,r):!1}async verifyInjection(e,r){if(!e)return!1;await new Promise(a=>setTimeout(a,300)),e.isConnected||(e=this.getInput()||e);const t=a=>(a||"").replace(/[\u200B-\u200D\uFEFF]/g,"").replace(/[*#_~`>+\-]/g,"").replace(/\u00A0/g," ").replace(/\s+/g," ").trim().toLowerCase(),n=t(r).substring(0,15);for(let a=0;a<8;a++){if(t(e.value||e.innerText||"").includes(n))return!0;a%2===0&&await this.triggerHumanSimulation(e),await new Promise(i=>setTimeout(i,300))}return!1}}/**
 * ============================================================================
 * LeanPrompts Studio
 * @author       Ivica Vrgoc
 * @link         https://github.com/IvicaV/LeanPrompts
 * @copyright    Copyright (c) 2025-present Ivica Vrgoc. All rights reserved.
 * @license      AGPL-3.0
 * ============================================================================
 * This file is part of LeanPrompts Studio.
 * 
 * LeanPrompts Studio is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Affero General Public License for more details.
 * ============================================================================
 */class P extends d{constructor(){super("Perplexity",["perplexity.ai"])}getInput(){const e=m();if(e)return e;const r=document.querySelector("div.bg-background .text-text-300")||document.querySelector('div[placeholder*="Ask"]')||Array.from(document.querySelectorAll("div")).find(t=>t.innerText==="Ask anything..."||t.innerText==="Frag irgendetwas ...");return r&&!r.dataset.lpClicked?(r.click(),r.dataset.lpClicked="true",null):document.querySelector("div#ask-input")||document.querySelector('textarea:not([style*="display: none"])')}async getFileInput(){const e=document.querySelector('input[type="file"]');if(e)return e;const r=document.querySelector('button[aria-label="Attach"]')||document.querySelector('button[aria-label="Anhängen"]')||document.querySelector('div[aria-label="Attach"]')||Array.from(document.querySelectorAll("button")).find(t=>t.innerText==="Attach"||t.innerText==="Anhängen");if(r){r.click();const t=await f(()=>document.querySelector('input[type="file"]'),2e3);if(t)return t}return l(document,t=>t.tagName==="INPUT"&&t.type==="file")[0]}async injectText(e,r){if(!e||!r)return!1;let t=e;if(!e.hasAttribute("data-slate-editor")){const s=document.querySelector('[data-slate-editor="true"]');s&&(t=s)}if(!t)return!1;t.focus(),await new Promise(s=>setTimeout(s,50));try{const s=window.getSelection(),c=document.createRange();c.selectNodeContents(t),c.collapse(!1),s.removeAllRanges(),s.addRange(c)}catch{}let a=r.split(`
`).map(s=>s.trim()===""?"<p><br></p>":`<p>${s.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;")}</p>`).join("");const o=new DataTransfer;o.setData("text/plain",r),o.setData("text/html",a);const i=new ClipboardEvent("paste",{bubbles:!0,cancelable:!0,composed:!0,view:window,clipboardData:o});return t.dispatchEvent(i),t.dispatchEvent(new InputEvent("input",{bubbles:!0,cancelable:!1,composed:!0,inputType:"insertFromPaste",data:null})),!0}async injectFiles(e){if(!e||e.length===0)return!1;const r=new DataTransfer;for(const a of e){const i=await(await fetch(a.data)).blob(),s=a.type||"application/octet-stream";r.items.add(new File([i],a.name,{type:s,lastModified:Date.now()}))}let t=l(document,a=>a.tagName==="INPUT"&&a.type==="file");if(t.length===0){const a=l(document,i=>{if(i.tagName!=="BUTTON"&&i.getAttribute("role")!=="button")return!1;const s=(i.innerText||"").toLowerCase(),c=(i.getAttribute("aria-label")||"").toLowerCase();return c.includes("attach")||c.includes("anhängen")||s==="attach"||s==="anhängen"}),o=a[a.length-1];if(o){o.click(),await new Promise(s=>setTimeout(s,500));const i=await f(()=>l(document,s=>s.tagName==="INPUT"&&s.type==="file")[0],2e3);i&&(t=[i])}}if(t.length===0)return!1;let n=!1;for(const a of t)try{const o=window.HTMLInputElement.prototype;Object.getOwnPropertyDescriptor(o,"files").set.call(a,r.files),a.dispatchEvent(new Event("change",{bubbles:!0,composed:!0})),a.dispatchEvent(new Event("input",{bubbles:!0,composed:!0})),a.dispatchEvent(new Event("blur",{bubbles:!0,composed:!0})),n=!0}catch{}return n&&await new Promise(a=>setTimeout(a,700)),n}}/**
 * ============================================================================
 * LeanPrompts Studio
 * @author       Ivica Vrgoc
 * @link         https://github.com/IvicaV/LeanPrompts
 * @copyright    Copyright (c) 2025-present Ivica Vrgoc. All rights reserved.
 * @license      AGPL-3.0
 * ============================================================================
 * This file is part of LeanPrompts Studio.
 * 
 * LeanPrompts Studio is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Affero General Public License for more details.
 * ============================================================================
 */class q extends d{constructor(){super("Kimi",["kimi.moonshot.cn","kimi.com","kimi.ai"])}getInput(){return document.querySelector('.chat-input-editor[contenteditable="true"]')||document.querySelector('[contenteditable="true"]')||m()}async getFileInput(){return await f(()=>document.querySelector('input[type="file"]')||l(document,e=>e.tagName==="INPUT"&&e.type==="file")[0],3e3)}async injectText(e,r){if(!e||!r)return!1;e.focus(),await new Promise(i=>setTimeout(i,50));const n=r.split(`
`).map(i=>i.trim()===""?"<p><br></p>":`<p>${i.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;")}</p>`).join(""),a=new DataTransfer;a.setData("text/plain",r),a.setData("text/html",n);const o=new ClipboardEvent("paste",{bubbles:!0,cancelable:!0,composed:!0,clipboardData:a});return e.dispatchEvent(o),e.dispatchEvent(new Event("input",{bubbles:!0})),!0}}/**
 * ============================================================================
 * LeanPrompts Studio
 * @author       Ivica Vrgoc
 * @link         https://github.com/IvicaV/LeanPrompts
 * @copyright    Copyright (c) 2025-present Ivica Vrgoc. All rights reserved.
 * @license      AGPL-3.0
 * ============================================================================
 * This file is part of LeanPrompts Studio.
 * 
 * LeanPrompts Studio is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Affero General Public License for more details.
 * ============================================================================
 */const A={"image/webp":"image/png","image/heic":"image/jpeg","image/heif":"image/jpeg"};class D extends d{constructor(){super("Qwen",["tongyi.aliyun.com","chat.qwenlm.ai","chat.qwen.ai"])}getInput(){return document.querySelector("textarea#chat-input")||document.querySelector(".ant-input-textarea textarea")||m()}async getFileInput(){return document.querySelector('input[type="file"]')||l(document,e=>e.tagName==="INPUT"&&e.type==="file")[0]}_sanitizeFile(e){const r=A[e.type]||e.type||"application/octet-stream",t=e.name.replace(/[^a-zA-Z0-9._-]/g,"_");return{...e,type:r,name:t}}async injectFiles(e){if(!e||e.length===0)return!1;console.log("LeanPrompts [Qwen] Starting file injection with",e.length,"file(s)");const r=this.getInput();if(!r)return console.error("LeanPrompts [Qwen] No textarea found"),!1;const t=e.map(a=>this._sanitizeFile(a)),n=[{name:"Drop on Textarea",fn:()=>this._tryDropOnTextarea(t,r)},{name:"Clipboard Paste",fn:()=>this._tryClipboardPaste(t,r)},{name:"Direct File Input",fn:()=>this._tryDirectFileInput(t)}];for(const a of n){console.log(`LeanPrompts [Qwen] Trying method: ${a.name}`);try{if(await a.fn())return await this._delay(800),await this._validateUpload(t)?(console.log(`LeanPrompts [Qwen] SUCCESS with method: ${a.name}`),!0):(console.log(`LeanPrompts [Qwen] Method ${a.name} dispatched, but validation timed out. Assuming success.`),!0)}catch(o){console.log(`LeanPrompts [Qwen] Method ${a.name} threw:`,o)}}return console.log("LeanPrompts [Qwen] All methods failed"),!1}async _tryDirectFileInput(e){var a;console.log("LeanPrompts [Qwen] Looking for hidden file input...");const r=await this.getFileInput();if(!r)return console.log("LeanPrompts [Qwen] No file input found"),!1;const t=new DataTransfer;if(e.forEach(o=>{try{const i=this._base64ToBlob(o.data,o.type),s=new File([i],o.name,{type:o.type,lastModified:Date.now()});t.items.add(s),console.log(`LeanPrompts [Qwen] Queued file: ${o.name} (${o.type})`)}catch(i){console.error(`LeanPrompts [Qwen] Error building File object for ${o.name}:`,i)}}),t.files.length===0)return!1;const n=r.getAttribute("accept");r.removeAttribute("accept");try{const o=window.HTMLInputElement.prototype,i=(a=Object.getOwnPropertyDescriptor(o,"files"))==null?void 0:a.set;return i?i.call(r,t.files):r.files=t.files,r.dispatchEvent(new Event("change",{bubbles:!0})),r.dispatchEvent(new Event("input",{bubbles:!0})),console.log(`LeanPrompts [Qwen] Set ${t.files.length} file(s) on native input`),!0}catch(o){return console.error("LeanPrompts [Qwen] Failed to set files on input:",o),!1}finally{n!==null&&r.setAttribute("accept",n)}}async _tryDropOnTextarea(e,r){console.log("LeanPrompts [Qwen] Attempting drop on textarea container...");const t=new DataTransfer;if(e.forEach(a=>{try{const o=this._base64ToBlob(a.data,a.type),i=new File([o],a.name,{type:a.type,lastModified:Date.now()});t.items.add(i)}catch(o){console.error("LeanPrompts [Qwen] Error building file for drop:",o)}}),t.files.length===0)return!1;const n=r.closest('[class*="composer"], [class*="input-area"], [class*="chat-input"]')||r.parentElement||r;return n&&(n.dispatchEvent(new DragEvent("dragenter",{bubbles:!0,cancelable:!0,dataTransfer:t})),n.dispatchEvent(new DragEvent("dragover",{bubbles:!0,cancelable:!0,dataTransfer:t})),n.dispatchEvent(new DragEvent("drop",{bubbles:!0,cancelable:!0,dataTransfer:t})),console.log("LeanPrompts [Qwen] Dispatched drop on ONE target:",n.className||n.tagName)),!0}async _tryClipboardPaste(e,r){console.log("LeanPrompts [Qwen] Attempting clipboard paste...");const t=new DataTransfer;if(e.forEach(a=>{try{const o=this._base64ToBlob(a.data,a.type),i=new File([o],a.name,{type:a.type,lastModified:Date.now()});t.items.add(i)}catch(o){console.error("LeanPrompts [Qwen] Error building file for paste:",o)}}),t.files.length===0)return!1;r.focus();const n=new ClipboardEvent("paste",{bubbles:!0,cancelable:!0,clipboardData:t});return r.dispatchEvent(n),console.log("LeanPrompts [Qwen] Dispatched paste event"),!0}async _validateUpload(e){console.log("LeanPrompts [Qwen] Validating upload...");const r=e.map(n=>n.name.toLowerCase()),t=Date.now();for(;Date.now()-t<6e3;){const n=document.querySelectorAll('[class*="file"], [class*="attachment"], [class*="upload"], [class*="chip"], [class*="card"], [class*="item"], .ant-upload-list-item, [data-testid*="file"]');for(const i of n){const s=(i.innerText||i.textContent||i.getAttribute("aria-label")||"").toLowerCase(),c=(i.getAttribute("title")||i.getAttribute("data-name")||"").toLowerCase();for(const p of r){const h=p.replace(/\.[^.]+$/,"");if(s.includes(p)||c.includes(p)||h.length>3&&s.includes(h))return console.log(`LeanPrompts [Qwen] ✓ Found file chip with name "${p}":`,i),!0}}const a=[".ant-upload-list-item-name",'[class*="file-name"]','[class*="filename"]','[class*="upload-success"]','[class*="file-preview"]','[class*="attachment-item"]'];for(const i of a){const s=document.querySelector(i);if(s){const c=(s.innerText||s.textContent||"").trim();if(c&&c.length>1&&!c.match(/^[+×✕✗\-]$/))return console.log(`LeanPrompts [Qwen] ✓ Found generic upload indicator [${i}]: "${c}"`),!0}}const o=['img[src^="blob:"]','img[class*="preview"]','[class*="image-preview"] img','[class*="image-item"] img'];for(const i of o)if(document.querySelector(i))return console.log(`LeanPrompts [Qwen] ✓ Found image preview [${i}]`),!0;await this._delay(300)}return console.warn("LeanPrompts [Qwen] Validation timeout - no upload indicator found after 6s"),!1}_base64ToBlob(e,r){const t=e.includes(",")?e.split(",")[1]:e,n=atob(t),a=[];for(let o=0;o<n.length;o+=512){const i=n.slice(o,o+512),s=new Array(i.length);for(let c=0;c<i.length;c++)s[c]=i.charCodeAt(c);a.push(new Uint8Array(s))}return new Blob(a,{type:r})}_delay(e){return new Promise(r=>setTimeout(r,e))}}/**
 * ============================================================================
 * LeanPrompts Studio
 * @author       Ivica Vrgoc
 * @link         https://github.com/IvicaV/LeanPrompts
 * @copyright    Copyright (c) 2025-present Ivica Vrgoc. All rights reserved.
 * @license      AGPL-3.0
 * ============================================================================
 * This file is part of LeanPrompts Studio.
 * 
 * LeanPrompts Studio is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Affero General Public License for more details.
 * ============================================================================
 */class C extends d{constructor(){super("Deepseek",["chat.deepseek.com"])}getInput(){return document.querySelector("textarea#chat-input")||m()}async getFileInput(){return await f(()=>l(document,e=>e.tagName==="INPUT"&&e.type==="file")[0],3e3)}}/**
 * ============================================================================
 * LeanPrompts Studio
 * @author       Ivica Vrgoc
 * @link         https://github.com/IvicaV/LeanPrompts
 * @copyright    Copyright (c) 2025-present Ivica Vrgoc. All rights reserved.
 * @license      AGPL-3.0
 * ============================================================================
 * This file is part of LeanPrompts Studio.
 * 
 * LeanPrompts Studio is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Affero General Public License for more details.
 * ============================================================================
 */class L extends d{constructor(){super("Grok",["grok.com","x.com"])}getInput(){const e=document.querySelector('div.tiptap.ProseMirror[contenteditable="true"]')||document.querySelector('.ProseMirror[contenteditable="true"]')||document.querySelector('div.tiptap[contenteditable="true"]');if(e)return console.log("[LeanPrompts Grok] Found ProseMirror editor"),e;const r=document.querySelector("textarea.w-full")||document.querySelector("textarea[placeholder]")||document.querySelector("textarea");if(r){console.log("[LeanPrompts Grok] Found TEXTAREA, clicking to activate ProseMirror"),r.click(),r.focus();const t=document.querySelector('div.tiptap.ProseMirror[contenteditable="true"]')||document.querySelector('.ProseMirror[contenteditable="true"]');return t?(console.log("[LeanPrompts Grok] ProseMirror activated after click"),t):r}return document.querySelector('div[role="textbox"]')||document.querySelector('div[contenteditable="true"]')||m()}async getFileInput(){return await f(()=>document.querySelector('input[type="file"].hidden')||document.querySelector('input[type="file"][data-testid="fileInput"]')||l(document,e=>e.tagName==="INPUT"&&e.type==="file")[0],3e3)}async injectText(e,r){if(!e||!r)return!1;if(console.log("[LeanPrompts Grok] injectText called with:",e.tagName,"contentEditable:",e.isContentEditable),e.tagName==="TEXTAREA"){e.click(),e.focus(),await new Promise(n=>setTimeout(n,300));const t=document.querySelector('div.tiptap.ProseMirror[contenteditable="true"]')||document.querySelector('.ProseMirror[contenteditable="true"]');t&&(console.log("[LeanPrompts Grok] Switching to ProseMirror after TEXTAREA activation"),e=t)}if(e.focus(),await new Promise(t=>setTimeout(t,100)),e.isContentEditable){console.log("[LeanPrompts Grok] Using paste for ContentEditable");const n=r.split(`
`).map(i=>i.trim()===""?"<p><br></p>":`<p>${i.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;")}</p>`).join(""),a=new DataTransfer;a.setData("text/plain",r),a.setData("text/html",n);const o=new ClipboardEvent("paste",{bubbles:!0,cancelable:!0,composed:!0,clipboardData:a});return e.dispatchEvent(o),e.dispatchEvent(new InputEvent("input",{bubbles:!0,inputType:"insertFromPaste"})),console.log("[LeanPrompts Grok] Paste dispatched to ContentEditable"),!0}if(e.tagName==="TEXTAREA"||e.tagName==="INPUT"){console.log("[LeanPrompts Grok] Using native setter with React valueTracker hack");try{const t=e.tagName==="TEXTAREA"?window.HTMLTextAreaElement.prototype:window.HTMLInputElement.prototype,n=Object.getOwnPropertyDescriptor(t,"value").set,a=e._valueTracker;a&&a.setValue(""),n.call(e,r);const o=new InputEvent("beforeinput",{bubbles:!0,composed:!0,inputType:"insertText",data:r,isComposing:!1});return e.dispatchEvent(o),e.dispatchEvent(new Event("input",{bubbles:!0,composed:!0})),e.dispatchEvent(new Event("change",{bubbles:!0,composed:!0})),e.dispatchEvent(new InputEvent("input",{bubbles:!0,inputType:"insertText",data:r})),console.log("[LeanPrompts Grok] Native setter with React hack applied"),!0}catch(t){return console.log("[LeanPrompts Grok] Error:",t),e.value=r,e.dispatchEvent(new Event("input",{bubbles:!0})),!0}}return super.injectText(e,r)}}/**
 * ============================================================================
 * LeanPrompts Studio
 * @author       Ivica Vrgoc
 * @link         https://github.com/IvicaV/LeanPrompts
 * @copyright    Copyright (c) 2025-present Ivica Vrgoc. All rights reserved.
 * @license      AGPL-3.0
 * ============================================================================
 * This file is part of LeanPrompts Studio.
 * 
 * LeanPrompts Studio is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Affero General Public License for more details.
 * ============================================================================
 */class k extends d{constructor(){super("Mistral",["mistral.ai","chat.mistral.ai"])}getInput(){return document.querySelector(".ProseMirror")||document.querySelector("div.ProseMirror")||document.querySelector("input#message")||document.querySelector("textarea")||m()}async getFileInput(){var t;let e=document.querySelector('input[type="file"]');if(e)return e;const r=document.querySelector('button[aria-label*="attach"]')||document.querySelector('button[aria-label*="Attach"]')||document.querySelector('button[aria-label*="upload"]')||document.querySelector('button[aria-label*="Upload"]')||document.querySelector('button[aria-label*="file"]')||document.querySelector('button[aria-label*="File"]')||((t=document.querySelector('button svg path[d*="M12"]'))==null?void 0:t.closest("button"))||Array.from(document.querySelectorAll("button")).find(n=>{var a,o,i;return((a=n.innerText)==null?void 0:a.toLowerCase().includes("attach"))||((o=n.innerText)==null?void 0:o.toLowerCase().includes("datei"))||((i=n.innerText)==null?void 0:i.toLowerCase().includes("upload"))});return r&&(r.click(),await new Promise(n=>setTimeout(n,800))),document.querySelector('input[type="file"]')||l(document,n=>n.tagName==="INPUT"&&n.type==="file")[0]}async verifyInjection(e,r){if(!e)return!1;document.body.contains(e)||(e=this.getInput()||e);const t=o=>(o||"").replace(/[\u200B-\u200D\uFEFF]/g,"").replace(/[*#_~`>+\-]/g,"").replace(/\u00A0/g," ").replace(/\s+/g," ").trim().toLowerCase(),n=t(r).substring(0,15);if(await new Promise(o=>setTimeout(o,50)),t((e.value||"")+" "+(e.innerText||"")+" "+(e.textContent||"")).includes(n))return!0;for(let o=0;o<8;o++)if(o%2===0&&await this.triggerHumanSimulation(e),await new Promise(s=>setTimeout(s,300)),t((e.value||"")+" "+(e.innerText||"")+" "+(e.textContent||"")).includes(n))return!0;return!1}async injectFiles(e){if(!e||e.length===0)return!1;const r=this.getInput();if(r)try{const n=await this._prepareDataTransfer(e);if(r.focus(),this.dispatchDropSequence(r,n))return await new Promise(o=>setTimeout(o,500)),!0}catch{}const t=await this.getFileInput();if(!t)return!1;try{const n=await this._prepareDataTransfer(e),a=window.HTMLInputElement.prototype;return Object.getOwnPropertyDescriptor(a,"files").set.call(t,n.files),t.dispatchEvent(new Event("change",{bubbles:!0,composed:!0})),t.dispatchEvent(new Event("input",{bubbles:!0,composed:!0})),!0}catch{return!1}}}/**
 * ============================================================================
 * LeanPrompts Studio
 * @author       Ivica Vrgoc
 * @link         https://github.com/IvicaV/LeanPrompts
 * @copyright    Copyright (c) 2025-present Ivica Vrgoc. All rights reserved.
 * @license      AGPL-3.0
 * ============================================================================
 * This file is part of LeanPrompts Studio.
 * 
 * LeanPrompts Studio is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Affero General Public License for more details.
 * ============================================================================
 */class N extends d{constructor(){super("Bing Image Creator",["bing.com/images/create","bing.com/create","bing.com/search"]),this._lastDeepScanTime=0,this._cachedDeepScanResult=null}getInput(){const e=document.querySelector("#sb_form_q, textarea.b_searchbox");if(e&&e.isConnected&&e.offsetWidth>0)return e;const r=Date.now();if(r-this._lastDeepScanTime<400)return this._cachedDeepScanResult&&this._cachedDeepScanResult.isConnected?this._cachedDeepScanResult:null;this._lastDeepScanTime=r;const n=l(document,a=>{const o=a.tagName.toLowerCase(),i=a.id||"",s=(a.className||"").toString(),c=a.getAttribute("data-testid")||"";return!!(o==="textarea"&&i==="searchbox"||o==="textarea"&&s.includes("text-area")||o==="input"&&c==="search-input")});if(n.length>0){const a=n.find(o=>o.offsetParent!==null&&!o.disabled&&!o.readOnly);if(a)return this._cachedDeepScanResult=a,a}return this._cachedDeepScanResult=null,null}async injectText(e,r){if(!e||!r)return!1;try{e.focus();const t=window.HTMLTextAreaElement.prototype;Object.getOwnPropertyDescriptor(t,"value").set.call(e,r);const a={bubbles:!0,cancelable:!0,composed:!0};return["input","change","keydown","keypress","keyup"].forEach(o=>{e.dispatchEvent(new Event(o,a))}),!0}catch{return await super.injectText(e,r)}}}/**
 * ============================================================================
 * LeanPrompts Studio
 * @author       Ivica Vrgoc
 * @link         https://github.com/IvicaV/LeanPrompts
 * @copyright    Copyright (c) 2025-present Ivica Vrgoc. All rights reserved.
 * @license      AGPL-3.0
 * ============================================================================
 * This file is part of LeanPrompts Studio.
 * 
 * LeanPrompts Studio is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Affero General Public License for more details.
 * ============================================================================
 */class F extends d{constructor(){super("Z.ai",["chat.z.ai","z.ai"])}}/**
 * ============================================================================
 * LeanPrompts Studio
 * @author       Ivica Vrgoc
 * @link         https://github.com/IvicaV/LeanPrompts
 * @copyright    Copyright (c) 2025-present Ivica Vrgoc. All rights reserved.
 * @license      AGPL-3.0
 * ============================================================================
 * This file is part of LeanPrompts Studio.
 * 
 * LeanPrompts Studio is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Affero General Public License for more details.
 * ============================================================================
 */class M extends d{constructor(){super("MiniMax",["agent.minimax.io"])}}/**
 * ============================================================================
 * LeanPrompts Studio
 * @author       Ivica Vrgoc
 * @link         https://github.com/IvicaV/LeanPrompts
 * @copyright    Copyright (c) 2025-present Ivica Vrgoc. All rights reserved.
 * @license      AGPL-3.0
 * ============================================================================
 * This file is part of LeanPrompts Studio.
 * 
 * LeanPrompts Studio is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Affero General Public License for more details.
 * ============================================================================
 */class _ extends d{constructor(){super("Generic",[])}detect(e){return!0}}/**
 * ============================================================================
 * LeanPrompts Studio
 * @author       Ivica Vrgoc
 * @link         https://github.com/IvicaV/LeanPrompts
 * @copyright    Copyright (c) 2025-present Ivica Vrgoc. All rights reserved.
 * @license      AGPL-3.0
 * ============================================================================
 * This file is part of LeanPrompts Studio.
 * 
 * LeanPrompts Studio is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Affero General Public License for more details.
 * ============================================================================
 */class j extends d{constructor(){super("Meta AI",["meta.ai"])}getInput(){return document.querySelector('textarea[aria-label*="Message"]')||document.querySelector('div[contenteditable="true"]')||null}async injectText(e,r){if(!e||!r)return!1;e.focus(),e.value!==void 0?e.value="":e.innerText="";try{const t=new DataTransfer;t.setData("text/plain",r);const n=new ClipboardEvent("paste",{bubbles:!0,cancelable:!0,composed:!0,clipboardData:t});return e.dispatchEvent(n),e.dispatchEvent(new InputEvent("input",{bubbles:!0,cancelable:!0,inputType:"insertFromPaste",data:r})),!0}catch(t){return console.error("LeanPrompts Meta: Paste failed, falling back",t),await super.injectText(e,r)}}}/**
 * ============================================================================
 * LeanPrompts Studio
 * @author       Ivica Vrgoc
 * @link         https://github.com/IvicaV/LeanPrompts
 * @copyright    Copyright (c) 2025-present Ivica Vrgoc. All rights reserved.
 * @license      AGPL-3.0
 * ============================================================================
 * This file is part of LeanPrompts Studio.
 * 
 * LeanPrompts Studio is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Affero General Public License for more details.
 * ============================================================================
 */class R{constructor(){this.strategies=[new N,new v,new D,new E,new x,new I,new P,new C,new q,new L,new k,new F,new M,new j],this.fallback=new _}getStrategy(e){for(const r of this.strategies)if(r.detect(e))return r;return this.fallback}getStrategyByName(e){return this.strategies.find(r=>r.name===e)||this.fallback}}const y=new R;/**
 * ============================================================================
 * LeanPrompts Studio
 * @author       Ivica Vrgoc
 * @link         https://github.com/IvicaV/LeanPrompts
 * @copyright    Copyright (c) 2025-present Ivica Vrgoc. All rights reserved.
 * @license      AGPL-3.0
 * ============================================================================
 * This file is part of LeanPrompts Studio.
 * 
 * LeanPrompts Studio is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Affero General Public License for more details.
 * ============================================================================
 */const B=[{name:"Bing Image Creator",matches:["bing.com/images/create","bing.com/create","bing.com/search"]},{name:"ChatGPT",matches:["chatgpt.com","chat.openai.com"]},{name:"Qwen",matches:["tongyi.aliyun.com","chat.qwenlm.ai","chat.qwen.ai"]},{name:"Claude",matches:["claude.ai"]},{name:"Gemini",matches:["gemini.google.com"]},{name:"Google AI Studio",matches:["aistudio.google.com"]},{name:"Perplexity",matches:["perplexity.ai"]},{name:"Deepseek",matches:["chat.deepseek.com"]},{name:"Kimi",matches:["kimi.moonshot.cn","kimi.com","kimi.ai"]},{name:"Z.ai",matches:["chat.z.ai","z.ai"]},{name:"MiniMax",matches:["agent.minimax.io"]},{name:"Grok",matches:["grok.com","x.com"]},{name:"Mistral",matches:["mistral.ai","chat.mistral.ai"]},{name:"Generic",matches:[]}],O=u=>{const e=y.getStrategy(u);return{name:e.name,matches:e.domains,getInput:()=>e.getInput(),getFileInput:async()=>e.getFileInput?await e.getFileInput():null,_strategy:e}},H=async(u,e,r)=>{if(!u||!e)return!1;const t=typeof window<"u"?window.location.hostname:"";return await(r?y.getStrategyByName(r):y.getStrategy(t)).injectText(u,e)},Q=async(u,e="Generic")=>{if(!u||u.length===0)return!1;const r=y.getStrategyByName(e),t=await r.injectFiles(u);if(t)return!0;if(e!=="Generic")return t;try{const n=await Promise.all(u.map(s=>fetch(s.data).then(c=>c.blob()).then(c=>new File([c],s.name,{type:s.type,lastModified:Date.now()})))),a=new DataTransfer;n.forEach(s=>a.items.add(s));const o=l(document,s=>s.tagName==="INPUT"&&s.type==="file");if(o.length>0){const s=o.find(c=>!c.disabled)||o[0];try{const c=window.HTMLInputElement.prototype;Object.getOwnPropertyDescriptor(c,"files").set.call(s,a.files)}catch{s.files=a.files}return s.dispatchEvent(new Event("change",{bubbles:!0,composed:!0})),s.dispatchEvent(new Event("input",{bubbles:!0,composed:!0})),!0}const i=r.getInput?r.getInput():m();return i&&(r.dispatchDropSequence(i,a)||i.parentNode&&r.dispatchDropSequence(i.parentNode,a))?!0:r.dispatchDropSequence(document.body,a)}catch(n){return console.error("File injection failed:",n),!1}};export{B as A,l as a,H as b,m as f,O as g,Q as i,f as w};
