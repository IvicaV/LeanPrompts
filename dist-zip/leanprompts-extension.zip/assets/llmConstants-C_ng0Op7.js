const w=(e,t)=>t.some(n=>e instanceof n);let I,S;function D(){return I||(I=[IDBDatabase,IDBObjectStore,IDBIndex,IDBCursor,IDBTransaction])}function A(){return S||(S=[IDBCursor.prototype.advance,IDBCursor.prototype.continue,IDBCursor.prototype.continuePrimaryKey])}const g=new WeakMap,h=new WeakMap,p=new WeakMap;function j(e){const t=new Promise((n,a)=>{const s=()=>{e.removeEventListener("success",i),e.removeEventListener("error",o)},i=()=>{n(l(e.result)),s()},o=()=>{a(e.error),s()};e.addEventListener("success",i),e.addEventListener("error",o)});return p.set(t,e),t}function v(e){if(g.has(e))return;const t=new Promise((n,a)=>{const s=()=>{e.removeEventListener("complete",i),e.removeEventListener("error",o),e.removeEventListener("abort",o)},i=()=>{n(),s()},o=()=>{a(e.error||new DOMException("AbortError","AbortError")),s()};e.addEventListener("complete",i),e.addEventListener("error",o),e.addEventListener("abort",o)});g.set(e,t)}let b={get(e,t,n){if(e instanceof IDBTransaction){if(t==="done")return g.get(e);if(t==="store")return n.objectStoreNames[1]?void 0:n.objectStore(n.objectStoreNames[0])}return l(e[t])},set(e,t,n){return e[t]=n,!0},has(e,t){return e instanceof IDBTransaction&&(t==="done"||t==="store")?!0:t in e}};function P(e){b=e(b)}function M(e){return A().includes(e)?function(...t){return e.apply(f(this),t),l(this.request)}:function(...t){return l(e.apply(f(this),t))}}function O(e){return typeof e=="function"?M(e):(e instanceof IDBTransaction&&v(e),w(e,D())?new Proxy(e,b):e)}function l(e){if(e instanceof IDBRequest)return j(e);if(h.has(e))return h.get(e);const t=O(e);return t!==e&&(h.set(e,t),p.set(t,e)),t}const f=e=>p.get(e);function T(e,t,{blocked:n,upgrade:a,blocking:s,terminated:i}={}){const o=indexedDB.open(e,t),u=l(o);return a&&o.addEventListener("upgradeneeded",c=>{a(l(o.result),c.oldVersion,c.newVersion,l(o.transaction),c)}),n&&o.addEventListener("blocked",c=>n(c.oldVersion,c.newVersion,c)),u.then(c=>{i&&c.addEventListener("close",()=>i()),s&&c.addEventListener("versionchange",d=>s(d.oldVersion,d.newVersion,d))}).catch(()=>{}),u}const B=["get","getKey","getAll","getAllKeys","count"],U=["put","add","delete","clear"],m=new Map;function x(e,t){if(!(e instanceof IDBDatabase&&!(t in e)&&typeof t=="string"))return;if(m.get(t))return m.get(t);const n=t.replace(/FromIndex$/,""),a=t!==n,s=U.includes(n);if(!(n in(a?IDBIndex:IDBObjectStore).prototype)||!(s||B.includes(n)))return;const i=async function(o,...u){const c=this.transaction(o,s?"readwrite":"readonly");let d=c.store;return a&&(d=d.index(u.shift())),(await Promise.all([d[n](...u),s&&c.done]))[0]};return m.set(t,i),i}P(e=>({...e,get:(t,n,a)=>x(t,n)||e.get(t,n,a),has:(t,n)=>!!x(t,n)||e.has(t,n)}));const N=["continue","continuePrimaryKey","advance"],k={},y=new WeakMap,E=new WeakMap,L={get(e,t){if(!N.includes(t))return e[t];let n=k[t];return n||(n=k[t]=function(...a){y.set(this,E.get(this)[t](...a))}),n}};async function*R(...e){let t=this;if(t instanceof IDBCursor||(t=await t.openCursor(...e)),!t)return;t=t;const n=new Proxy(t,L);for(E.set(n,t),p.set(n,f(t));t;)yield n,t=await(y.get(n)||t.continue()),y.delete(n)}function C(e,t){return t===Symbol.asyncIterator&&w(e,[IDBIndex,IDBObjectStore,IDBCursor])||t==="iterate"&&w(e,[IDBIndex,IDBObjectStore])}P(e=>({...e,get(t,n,a){return C(t,n)?R:e.get(t,n,a)},has(t,n){return C(t,n)||e.has(t,n)}}));/**
 * ============================================================================
 * LeanPrompts Studio
 * @author       Ivica Vrgoc
 * @link         https://github.com/IvicaV/LeanPrompts
 * @copyright    Copyright (c) 2025-present Ivica Vrgoc. All rights reserved.
 * @license      AGPL-3.0
 * ============================================================================
 * This file is part of LeanPrompts Studio.
 * 
 * LeanPrompts Studio is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Affero General Public License for more details.
 * ============================================================================
 */const _="LeanPromptsDB",V=9,r=async()=>T(_,V,{upgrade(e,t,n,a){if(!e.objectStoreNames.contains("prompts")){const o=e.createObjectStore("prompts",{keyPath:"id"});o.createIndex("updatedAt","updatedAt"),o.createIndex("tags","tags",{multiEntry:!0}),o.createIndex("collectionId","collectionId")}const s=a.objectStore("prompts");if(s.indexNames.contains("isPinned")||s.createIndex("isPinned","isPinned"),s.indexNames.contains("usageCount")||s.createIndex("usageCount","usageCount"),s.indexNames.contains("collectionId")||s.createIndex("collectionId","collectionId"),!e.objectStoreNames.contains("snippets")){const o=e.createObjectStore("snippets",{keyPath:"id"});o.createIndex("name","name",{unique:!0}),o.createIndex("updatedAt","updatedAt")}const i=a.objectStore("snippets");if(i.indexNames.contains("tags")||i.createIndex("tags","tags",{multiEntry:!0}),i.indexNames.contains("collectionId")||i.createIndex("collectionId","collectionId"),!e.objectStoreNames.contains("collections")){const o=e.createObjectStore("collections",{keyPath:"id"});o.createIndex("name","name"),o.createIndex("updatedAt","updatedAt")}if(!e.objectStoreNames.contains("knowledge")){const o=e.createObjectStore("knowledge",{keyPath:"id"});o.createIndex("title","title"),o.createIndex("updatedAt","updatedAt"),o.createIndex("tags","tags",{multiEntry:!0}),o.createIndex("collectionId","collectionId")}e.objectStoreNames.contains("session_cache")||e.createObjectStore("session_cache",{keyPath:"id"}),e.objectStoreNames.contains("backups")||e.createObjectStore("backups",{keyPath:"id"})}}),F={async saveSessionCache(e,t){return(await r()).put("session_cache",{id:e,data:t,updatedAt:new Date().toISOString()})},async getSessionCache(e){const n=await(await r()).get("session_cache",e);return(n==null?void 0:n.data)||null},async clearSessionCache(){return(await r()).clear("session_cache")},async saveShadowBackup(e,t){return(await r()).put("backups",{id:e,data:t,updatedAt:new Date().toISOString()})},async getShadowBackup(e){return(await r()).get("backups",e)},async clearShadowBackup(e){return(await r()).delete("backups",e)},async getAllPrompts(){return(await r()).getAllFromIndex("prompts","updatedAt")},async savePrompt(e){return(await r()).put("prompts",e)},async deletePrompt(e){return(await r()).delete("prompts",e)},async getPrompt(e){return(await r()).get("prompts",e)},async getAllSnippets(){return(await r()).getAllFromIndex("snippets","updatedAt")},async saveSnippet(e){return(await r()).put("snippets",e)},async deleteSnippet(e){return(await r()).delete("snippets",e)},async getAllCollections(){return(await r()).getAllFromIndex("collections","updatedAt")},async saveCollection(e){return(await r()).put("collections",e)},async deleteCollection(e){return(await r()).delete("collections",e)},async getAllKnowledge(){return await(await r()).getAllFromIndex("knowledge","updatedAt")||[]},async saveKnowledge(e){return(await r()).put("knowledge",e)},async deleteKnowledge(e){return(await r()).delete("knowledge",e)},async bulkDeleteKnowledge(e){const n=(await r()).transaction("knowledge","readwrite");await Promise.all(e.map(a=>n.store.delete(a))),await n.done},async bulkPutPrompts(e){if(!e||e.length===0)return;const n=(await r()).transaction("prompts","readwrite");await Promise.all(e.map(a=>n.store.put(a))),await n.done},async bulkPutSnippets(e){if(!e||e.length===0)return;const n=(await r()).transaction("snippets","readwrite");await Promise.all(e.map(a=>n.store.put(a))),await n.done},async bulkPutKnowledge(e){if(!e||e.length===0)return;const n=(await r()).transaction("knowledge","readwrite");await Promise.all(e.map(a=>n.store.put(a))),await n.done},async seedIfEmpty(e,t){const n=await r();if(await n.count("prompts")===0){const s=n.transaction(["prompts","snippets"],"readwrite");if(e&&e.length>0){const i=s.objectStore("prompts");for(const o of e)await i.add(o)}if(t&&t.length>0&&(s.objectStore("snippets"),n.objectStoreNames.contains("snippets")))for(const i of t)await s.objectStore("snippets").put(i);return await s.done,!0}return!1},async clearAllData(){const e=await r(),t=["prompts","snippets","collections","knowledge","session_cache","backups"],n=e.transaction(t,"readwrite");await Promise.all(t.map(a=>n.objectStore(a).clear())),await n.done}},K=Object.freeze(Object.defineProperty({__proto__:null,dbAPI:F,initDB:r},Symbol.toStringTag,{value:"Module"}));/**
 * ============================================================================
 * LeanPrompts Studio
 * @author       Ivica Vrgoc
 * @link         https://github.com/IvicaV/LeanPrompts
 * @copyright    Copyright (c) 2025-present Ivica Vrgoc. All rights reserved.
 * @license      AGPL-3.0
 * ============================================================================
 * This file is part of LeanPrompts Studio.
 * 
 * LeanPrompts Studio is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Affero General Public License for more details.
 * ============================================================================
 */const z=[{id:"demo-snippet-1",name:"Expert",content:`You are an elite, world-class expert in your field.
Your goal is to break down complex concepts with absolute clarity, avoiding unnecessary jargon and corporate fluff.

Please tailor your explanation perfectly for an audience of: {{Audience_Level: beginner}}.

%%
💡 THE "WRITE ONCE, UPDATE EVERYWHERE" RULE
This is a Snippet. Think of it as a reusable building block. 

Instead of copy-pasting your favorite persona into 50 different prompts, you just type @Expert. The best part? If you ever tweak this text here, EVERY prompt in your library using it updates instantly.

Notice the variable above? Snippets can contain their own variables! When you use this snippet in a prompt, that variable will automatically appear in your sidebar ready to be filled out.
%%`,updatedAt:new Date().toISOString()}],H=[{id:"demo-prompt-1",title:"✨ Welcome to LeanPrompts",content:`@Expert

Analyze the attached document: {{file: Reference_Material}}

Select your workflow: {{Mode: Quick|Thorough|Creative}}

%%
PRO-TIPS:
1. DROPDOWN: Use {{Key: Option1|Option2}} to create interactive menus.
2. PASTE: Copy any image to your clipboard and press Ctrl+V over the file zone.
3. COMMENT: Use %% comments %% to leave internal notes the AI won't see.
4. REQUIRED: Use {{!Variable}} to make a field mandatory.
%%`,chain:[{id:"demo-step-1",title:"🎯 Smart Filling",content:`@Expert

Analyze the attached document: {{file: Reference_Material}}

Select your workflow: {{Mode: Quick|Thorough|Creative}}`,notes:"This step shows how variables and files link together.",versions:[],isVisible:!0},{id:"demo-step-2",title:"⛓️ Phase 2: Chaining & Roadmaps",content:`Excellent. Now, based on the roadmap you just created in the previous step, let's execute the first phase.

Please provide **3 highly specific, practical exercises** I can do today to get started. Format the output as a clean Markdown table.

%%
🧠 WHY CHAINS ARE POWERFUL
Don't ask the AI to do 10 complex things at once. It will hallucinate.
Instead, build "Prompt Chains". Inject Step 1, wait for the AI's output, then inject Step 2. This forces a logical "Chain of Thought".

🔥 PRO TIP: Try changing a word in this text right now, then check the "History" tab on the right. LeanPrompts automatically takes snapshots of your edits so you never lose a good prompt version!
%%`,notes:"",versions:[],isVisible:!0}],tags:["Tutorial","Getting Started"],versions:[],updatedAt:new Date().toISOString()}];/**
 * ============================================================================
 * LeanPrompts Studio
 * @author       Ivica Vrgoc
 * @link         https://github.com/IvicaV/LeanPrompts
 * @copyright    Copyright (c) 2025-present Ivica Vrgoc. All rights reserved.
 * @license      AGPL-3.0
 * ============================================================================
 * This file is part of LeanPrompts Studio.
 * 
 * LeanPrompts Studio is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Affero General Public License for more details.
 * ============================================================================
 */const W=[{id:"aistudio",name:"AI Studio",url:"https://aistudio.google.com",newChatUrl:"https://aistudio.google.com/prompts/new_chat",icon:"google"},{id:"gpt4",name:"ChatGPT",url:"https://chatgpt.com",newChatUrl:"https://chatgpt.com/?model=auto",icon:"openai"},{id:"claude",name:"Claude",url:"https://claude.ai",newChatUrl:"https://claude.ai/new",icon:"anthropic"},{id:"gemini",name:"Gemini",url:"https://gemini.google.com",newChatUrl:"https://gemini.google.com/app",icon:"google"},{id:"perplexity",name:"Perplexity",url:"https://www.perplexity.ai",newChatUrl:"https://www.perplexity.ai/",icon:"search"},{id:"grok",name:"Grok",url:"https://grok.com",newChatUrl:"https://grok.com/",icon:"sparkles"},{id:"deepseek",name:"Deepseek",url:"https://chat.deepseek.com",newChatUrl:"https://chat.deepseek.com/",icon:"brain"},{id:"qwen",name:"Qwen",url:"https://chat.qwenlm.ai",newChatUrl:"https://chat.qwenlm.ai/",icon:"message-square",alternativeDomains:["chat.qwen.ai","tongyi.aliyun.com"]},{id:"kimi",name:"Kimi",url:"https://www.kimi.com",newChatUrl:"https://www.kimi.com/chat",icon:"moon"},{id:"poe",name:"Poe",url:"https://poe.com",newChatUrl:"https://poe.com/",icon:"bot"},{id:"mistral",name:"Mistral",url:"https://chat.mistral.ai",newChatUrl:"https://chat.mistral.ai/chat",icon:"wind"},{id:"zai",name:"Z.ai",url:"https://chat.z.ai",newChatUrl:"https://chat.z.ai",icon:"zap"},{id:"minimax",name:"MiniMax",url:"https://agent.minimax.io",newChatUrl:"https://agent.minimax.io",icon:"bot"},{id:"meta",name:"Meta AI",url:"https://www.meta.ai",newChatUrl:"https://www.meta.ai/",icon:"message-circle"}],Y=e=>{if(!e)return null;const t=W.find(n=>n.id===e.id);return t?{...e,newChatUrl:t.newChatUrl}:e.newChatUrl?e:{...e,newChatUrl:e.url}},q=(e,t="Content")=>`Click: Inject ${t} into ${e}
Ctrl+Click: New Chat & Inject
Shift+Click: Open ${e}`;export{W as D,H as S,z as a,Y as b,K as c,F as d,q as g};
